/**
 * Dr. Faizan Shabbir Rana - Clinical Urology & Kidney Surgery Theme JS
 */

document.addEventListener('DOMContentLoaded', () => {
  initMobileMenu();
  initAppointmentBooking();
  initSmoothScroll();
  initProcedureQuickBook();
});

// Mobile Menu
function initMobileMenu() {
  const menuBtn = document.getElementById('mobileMenuBtn');
  const navLinks = document.querySelector('.nav-links');

  if (menuBtn && navLinks) {
    menuBtn.addEventListener('click', () => {
      const isExpanded = navLinks.style.display === 'flex';
      navLinks.style.display = isExpanded ? 'none' : 'flex';
      navLinks.style.flexDirection = 'column';
      navLinks.style.position = 'absolute';
      navLinks.style.top = '80px';
      navLinks.style.left = '0';
      navLinks.style.width = '100%';
      navLinks.style.background = 'rgba(7, 17, 38, 0.98)';
      navLinks.style.padding = '20px';
      navLinks.style.borderBottom = '1px solid rgba(212, 175, 55, 0.2)';
    });
  }
}

// Interactive Appointment Booking & WhatsApp Dispatch
function initAppointmentBooking() {
  const bookingForm = document.getElementById('appointmentForm');
  const procedureSelect = document.getElementById('bookingProcedure');
  const hospitalSelect = document.getElementById('bookingHospital');
  const patientNameInput = document.getElementById('patientName');
  const patientPhoneInput = document.getElementById('patientPhone');
  const appointmentDateInput = document.getElementById('appointmentDate');
  const formFeedback = document.getElementById('bookingFeedback');

  if (bookingForm) {
    bookingForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = patientNameInput ? patientNameInput.value.trim() : '';
      const phone = patientPhoneInput ? patientPhoneInput.value.trim() : '';
      const procedure = procedureSelect ? procedureSelect.value : '';
      const hospital = hospitalSelect ? hospitalSelect.value : '';
      const date = appointmentDateInput ? appointmentDateInput.value : '';

      if (!name || !phone || !procedure || !hospital) {
        alert('Please fill out all required fields.');
        return;
      }

      // Generate pre-filled WhatsApp link
      const message = 
        `Assalam-o-Alaikum Dr. Faizan Shabbir Rana,\n` +
        `I would like to book a clinical appointment.\n\n` +
        `• Patient Name: ${name}\n` +
        `• Contact Number: ${phone}\n` +
        `• Treatment / Procedure: ${procedure}\n` +
        `• Hospital / Location: ${hospital}\n` +
        `• Preferred Date: ${date || 'Earliest Available'}\n\n` +
        `Please confirm available slot. Thank you!`;

      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/923127064602?text=${encodedMessage}`;

      if (formFeedback) {
        formFeedback.innerHTML = `
          <div style="background: rgba(5, 150, 105, 0.2); border: 1px solid #10b981; color: #a7f3d0; padding: 14px; border-radius: 10px; margin-top: 14px;">
            <strong>Appointment Request Ready!</strong> Redirecting to WhatsApp for instant confirmation...
          </div>
        `;
      }

      setTimeout(() => {
        window.open(whatsappUrl, '_blank');
      }, 700);
    });
  }
}

// Procedure Card Quick-Book Handler
function initProcedureQuickBook() {
  const quickBookBtns = document.querySelectorAll('.service-btn-book');
  const procedureSelect = document.getElementById('bookingProcedure');
  const bookingSection = document.getElementById('appointment');

  quickBookBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const procedureName = btn.getAttribute('data-procedure');
      if (procedureSelect && procedureName) {
        procedureSelect.value = procedureName;
      }
      if (bookingSection) {
        bookingSection.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

// Smooth Scrolling
function initSmoothScroll() {
  const links = document.querySelectorAll('a[href^="#"]');
  links.forEach(link => {
    link.addEventListener('click', function(e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        targetEl.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}
